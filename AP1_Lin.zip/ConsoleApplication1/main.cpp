 /*
 * Binary Search Tree implementation - heavily lifted from https://gist.github.com/mgechev/5911348
 *
 * Simple integer keys and basic operations
 * Now also doing testing & height calculations
 *
 * Aaron Crandall - 2016 - Added / updated:
 *  * Inorder, Preorder, Postorder printouts
 *  * Stubbed in level order printout
 *  * Also doing height calculations
 *
 */

//My visual studio crashed when computing the number of values for the datacase. I changed the number of values to 98 in order to see if I could generate the values to the csv files. 
//Please change it to its original value before testing.

#include <iostream>
#include <queue>
#include <cstring>
#include "BST.h"
#include "TestData.h"
#include <string.h>
using namespace std;


/*
 *  Interface to run all tests if --test is passed on command line
 */
void runTests() {
    cout << " [x] Running tests. " << endl;
    TestData *testing = new TestData();            // Create object with testing data and interfaces

  BST<int> *bst_test = new BST<int>;

    /* Should make a tree like this:
              10
         5          14
     1      7           17
                            19
                          18

   */
    int testval = testing->get_next_minitest();
    while( testval >= 0 ){
        bst_test->add( testval );
        testval = testing->get_next_minitest();
    }
    cout << " [x] Should print out in pre order: 10 5 1 7 14 17 19 18 " << endl;
  cout << " [x] Resulting print out test:      ";
    bst_test->printPreOrder();
  cout << endl;

    cout << " [x] Should print a tree height of  : 5" << endl;
    cout << " [x] Currently calculating height of: ";
  cout << bst_test->height(); 
  cout << endl;

  cout << "# of Node Elements: " <<  bst_test->nodeCount() << endl;

  
}


/*
 * Generate the CSV file for the project output here
 */
void genCSV() {
    TestData *tests = new TestData();            // Create object with testing data and interfaces
    BST<int> *bst_sorted = new BST<int>;
    BST<int> *bst_sorted2 = new BST<int>;
    BST<int> *bst_balanced = new BST<int>;
    BST<int> *bst_zero = new BST<int>;
    BST<int> *bst_one = new BST<int>;
    BST<int> *bst_two = new BST<int>;
    BST<int> *bst_three = new BST<int>;
    BST<int> *bst_four = new BST<int>;

    cout << "Hello World!" << endl;
    cout << " [x] Generating CSV output file. " << endl;

    ofstream myfile;
    myfile.open("OutputData.csv");
    myfile << "N Size, log_2(N), Sorted, Balanced";    //Labeled first 3 Axis
    myfile << ",";
    for (int x = 0; x < 5; x++) {
        myfile << " Scrambled #" << x << ",";
    }
    myfile << "\n";
    //  Sample of how to use the TestData structure for getting the test data sets
    int sorted = tests->get_next_sorted();
    int counting = tests ->get_next_sorted();
    int balanced = tests->get_next_balanced(); //getting the values for each test cases
    int zero = tests->get_next_scrambled(0);
    int one = tests->get_next_scrambled(1);
    int two = tests->get_next_scrambled(2);
    int three = tests->get_next_scrambled(3);
    int four = tests->get_next_scrambled(4);

    int a = 0;

     
    while (counting >= 0) {
        bst_sorted2->add(counting); //getting the number of elements in the trees
        counting = tests->get_next_sorted();
    }
    a = bst_sorted2->nodeCount();
    

    while(a>=0) {
    bst_sorted->add(sorted);
    bst_balanced->add(balanced);
    bst_zero->add(zero);       //generating values to output to the appropriate columns in the csv file
    bst_one->add(one);
    bst_two->add(two);
    bst_three->add(three);
    bst_four->add(four);

    myfile << bst_sorted->nodeCount() << "," << bst_sorted->logn(bst_sorted->nodeCount()) << "," << bst_sorted->height() << "," << bst_balanced->height() << "," << bst_zero->height() << "," << bst_one->height() << "," << bst_two->height() << "," << bst_three->height() << "," << bst_four->height();
    myfile << "\n";
    sorted = tests->get_next_sorted();
    balanced = tests->get_next_balanced();
    zero = tests->get_next_scrambled(0);
    one = tests->get_next_scrambled(1);
    two = tests->get_next_scrambled(2);
    three = tests->get_next_scrambled(3);
    four = tests->get_next_scrambled(4);
    a--;

}
    
 
     

    // make a file: OutputData-BST.csv
        // make 7 trees (sorted, balanced, scrambled[0..4])
        // fill trees with data from TestData
        //  -- as you fill, get the heights and output to CSV file: log_2 N, height sorted, height balanced, height scrambled[0..4]
    //  -- fill until the get_next_* functions return -1
}


/*
 *   Main function for execution
 */
int main( int argc, char* argv[] ) {
    if(argc > 1 && argv[1], "--test") //argc > 1	//!!!Error here, even though it's starter code
    {
        cout << " [x] Program in test mode, doing simple tests. " << endl;
        runTests();  // testing should just do a simple tree insert set and search
    }


    else
    {
        cout << " [x] Program built and running in full CSV generation mode. " << endl;
     
    }
    genCSV();

    return 0;
}


