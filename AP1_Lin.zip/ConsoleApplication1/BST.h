/*
 * Binary Search Tree implementation - heavily lifted from https://gist.github.com/mgechev/5911348
 *
 * Simple integer keys and basic operations
 *
 * Aaron Crandall - 2016 - Added / updated:
 *  * Inorder, Preorder, Postorder printouts
 *  * Stubbed in level order printout
 *
 */

#ifndef _BST_H
#define _BST_H

#include <math.h>
#include <iostream>
#include <queue>

#include <fstream>

using namespace std;

/*
 *  Node datastructure for single tree node
 */ 
template <class T>
struct Node {
    T value;
    Node<T> *left=nullptr;
    Node<T> *right=nullptr;

    Node(T content) {
        this->value = content;
    }

    Node(T value, Node<T>*left, Node<T>*right) {
            this->value = value; //creating node
            this->left = left;
            this->right = right;
    }
};


/*
 * Binary Search Tree (BST) class implementation
 */
template <class T>
class BST {
    
private:
    Node<T> *root = nullptr;
     

public:
     
         


    void insert(T val2, Node<T>*someNode) {

        if (!someNode) { //if there's no new node then don't do anything
            return;
        }
        if (val2 < someNode->value) {  //is val2 is less than someNode and if there's a left child for it then recursively call again
            if (someNode->left) {
                insert(val2, someNode->left);
            }
            else {
                someNode->left = new Node<T>(val2); //else if not then make val2 new node for the place
            }
        }
        else if (val2 > someNode->value) {
            if (someNode->right) {
                insert(val2, someNode->right); //same for if val2 is bigger than someNode's value
            }
            else {
                someNode->right = new Node<T>(val2);

            }
        }


    }



    void add(T val) {
        Node<T> *newNode = new Node<T>(val);
        if (!root) {
            root = newNode;                            //if no root node then make value the new root node
        }
        else if (!root->left && val<root->value) { //if no left node and val is less than root's value then make it the new left node
            root->left = new Node<T>(val);
        }
        else if (!root->right && val > root->value) { //same for right if val is bigger than root's value
            root->right = new Node<T>(val);
        }
        else {
            insert(val, root);

        }
    }


    void print() {
        this->printPreOrder();
    }

    void printPreOrder() {
        Node<T>*test = root;  //if no node then just leave it
        if (root == NULL){
            return;
        }
        else {      
            printingorder(test);
        }
        //cout << "a: " << root->left->value << endl;

    }

    void printingorder(Node<T>*roots) {
        //int a = 0;
        if (roots == NULL) { //if nothing in the node then just leave it
            return;
        } 
        cout << roots->value << ',';
        printingorder(roots->left); //else recursively go through the nodes and print out the values
        printingorder(roots->right);
    }

    int countRecursion(Node<T>*root) {
        int a = 0, b = 0;
        if (!root) {   //if no node then return 0;
            return 0;
        }
        else {
            a = countRecursion(root->left); //continously go through each node and count
            b = countRecursion(root->right);
        }
         
        if (a > b) {
            return a = a + 1;     //counting height is finding the most amount biggest path
        }
        else b = b + 1;
        return b;

    }
    
    int height() {
        if (root == NULL) { //if no node then return 0;
            return 0;
        }
        else {
            return countRecursion(root);
        } 
        
    }

    int nodeCount() {
        if (!root) {  //if tree has no elements
            return 0; //return 0;
        }
        else {
            return noderecurs(root); //else recursively find elements in tree
        }
        
    }

    int noderecurs(Node<T>*roots) {
        int c = 0, d = 0;   //recursive function to find # of elements in tree
        if (!roots) {
            return 0;  //return 0 if it is null
        }
        else {
            c = noderecurs(roots->left);  //recursively go through the tree
            d = noderecurs(roots->right);
        }
        return c + d + 1;  //total elements
    }

    int logn(int a) {
        int result = log2(a); //log_2(N) function
        return result;
    }
     
    
};

#endif

